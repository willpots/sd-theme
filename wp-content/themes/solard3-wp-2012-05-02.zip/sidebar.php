<div id="sidebar">
	<h4>About</h4>
	<p>Welcome to the online home of InSite and Team Middlebury College 2013.</p>
	<h4>Search</h4>
	<!-- Search Function Goes Here -->
	<h4>Upcoming Events</h4>
	<!-- How do we want to do this?  Hard, calendar integration, or what? -->
	<!-- Twitter integration goes here -->
	<!-- Facebook, Twitter, Youtube, RSS Links -->
</div>