	</div> <!-- container -->
</div> <!-- content_background -->
<div id="footer">
	<img id="logo_midd" class="logo" src="<?php bloginfo("stylesheet_directory"); ?>/img/midd.png" />
	<img id="logo_nrel" class="logo" src="<?php bloginfo("stylesheet_directory"); ?>/img/nrel2.png" />
	<img id="logo_doe" class="logo" src="<?php bloginfo("stylesheet_directory"); ?>/img/doe.png" />
	<img id="logo_sd" class="logo" src="<?php bloginfo("stylesheet_directory"); ?>/img/sd.png" />
</div><!-- #footer -->
<!-- <?php analytics(); ?> -->
</body>
</html>